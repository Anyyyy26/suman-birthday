Multi-page Romantic Birthday Website for Suman (Rose-Gold theme)

How to use:
1. Unzip this folder.
2. Open in VS Code: File → Open Folder → final_custom_birthday_site
3. Install Live Server extension.
4. Right-click index.html → Open with Live Server
5. The site has five pages: index.html -> reveal.html -> gallery.html -> letter.html -> surprise.html
6. Replace [Your Name] in letter.html with your name if desired.
7. Replace img1..img20 with real photos (keep filenames or update gallery.js).
8. Replace music.mp3 to change background music (your uploaded mp3 should be named music.mp3).